package com.example.phoneauth;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.phoneauth.databinding.ActivityDashboardBinding;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONException;
import org.json.JSONObject;

public class Dashboard extends AppCompatActivity implements PaymentResultListener {

    ActivityDashboardBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String sAmount = binding.amount.getText().toString();

                int amount = Math.round(Float.parseFloat(sAmount)*100);

                Checkout checkout = new Checkout();

                checkout.setKeyID("rzp_test_g6RGzypM8Cd8Gw");

                checkout.setImage(R.drawable.qrcode);

                JSONObject object = new JSONObject();

                try {
                    object.put("name", "Daksh Pathak");
                    object.put("description", "Test Payment");
                    object.put("theme.color","#0093DD");
                    object.put("currency","INR");
                    object.put("amount",amount);
                    object.put("prefill.contact","7000472097");
                    object.put("prefill.email","dakshpathak0705@gmail.com");
                    checkout.open(Dashboard.this,object);
                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
        });

    }

    @Override
    public void onPaymentSuccess(String s) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Payment ID");

        builder.setMessage(s);

        builder.show();
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(getApplicationContext(),s, Toast.LENGTH_SHORT).show();

    }
}