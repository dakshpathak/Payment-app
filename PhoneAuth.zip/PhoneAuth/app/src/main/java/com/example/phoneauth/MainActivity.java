package com.example.phoneauth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import com.example.phoneauth.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.getotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String contact = binding.number.getText().toString();
                if (contact.length()==10){
                    boolean ans = validateContact(contact);
                    if (ans == true ){
                        Toast.makeText(MainActivity.this, "Entered successfully!", Toast.LENGTH_SHORT).show();

                        SharedPreferences sharedPreferences = getSharedPreferences("number", Context.MODE_PRIVATE);
                        SharedPreferences.Editor shared = sharedPreferences.edit();

                        shared.putString("contact", "+91"+contact);
                        shared.apply();

                        Intent intent = new Intent(MainActivity.this, manageOtp.class);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                   binding.number.setError("Invalid number!");
                }

            }
        });


    }
    boolean validateContact(String num){
        if (Patterns.PHONE.matcher(num).matches()){
            return true;
        }

            binding.number.setError("Invalid number!");
            return false;

    }

}